class Cruiser < Ship

  def initialize
    super(2, 4)
  end

end
