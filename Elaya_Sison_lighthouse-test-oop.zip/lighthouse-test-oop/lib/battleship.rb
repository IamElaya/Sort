class Battleship < Ship

  def initialize
    super(4, 4)
  end

end
